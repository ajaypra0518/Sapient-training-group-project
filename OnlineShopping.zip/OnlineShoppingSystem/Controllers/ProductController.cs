﻿using Logging_Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnlineShopping_BAL.Service;
using OnlineShopping_DAL.Interface;
using OnlineShopping_DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineShoppingSystem.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly ProductService onlineService;
        private readonly IProductRepository<Product> productRepo;
        private readonly ICategoryRepository<Category> categoryRepo;
        Logging lg = new Logging();
        public ProductController(ProductService service, IProductRepository<Product> product, ICategoryRepository<Category> category)
        {
            onlineService = service;
            productRepo = product;
            categoryRepo = category;
        }

        [HttpGet("/viewproducts")]
        public IEnumerable<Product> ViewProducts()
        {
            try
            {
                lg.LogInfo("Entered in ViewProducts");
                return onlineService.ViewProducts();
            }
            catch (Exception ex)
            {
                lg.LogError("Message:" + ex.Message + " StackTrace:" + ex.StackTrace);
                throw;
            }

        }

        [HttpGet("/viewcategories")]

        public IEnumerable<Category> ViewCategories()
        {
            try
            {
                lg.LogInfo("Entered in ViewCategories");
                return onlineService.ViewCategories();
            }
            catch (Exception ex)
            {
                lg.LogError("Message:" + ex.Message + " StackTrace:" + ex.StackTrace);
                throw;
            }

        }

        [HttpGet("/searchbyid/{PId}")]
        public Object SearchByProductID(int PId)
        {
            try
            {
                lg.LogInfo("Entered in SearchByProductID");
                return onlineService.SearchByProductID(PId);


            }
            catch (Exception ex)
            {
                lg.LogError("Message:" + ex.Message + " StackTrace:" + ex.StackTrace);
                throw;
            }

        }

        [HttpGet("/getbycategoryid/{CId}")]
        public Object GetProductByCategory(int CId)
        {
            try
            {
                lg.LogInfo("Entered in GetProductByCategory");
                return onlineService.GetProductByCategoryId(CId);
            }
            catch (Exception ex)
            {
                lg.LogError("Message:" + ex.Message + " StackTrace:" + ex.StackTrace);
                throw;
            }

        }

        [HttpGet("/searchbycategoryidrange/{CId}/{start}/{end}")]
        public Object SearchByRange(int CId, int start, int end)
        {
            try
            {
                lg.LogInfo("Entered in SearchByRange");
                return onlineService.SearchByPriceRange(CId, start, end);
            }

            catch (Exception ex)
            {
                lg.LogError("Message:" + ex.Message + " StackTrace:" + ex.StackTrace);
                throw;
            }



        }
    }
}
