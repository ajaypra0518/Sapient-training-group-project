﻿using Logging_Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using OnlineShopping_BAL.Service;
using OnlineShopping_DAL.Interface;
using OnlineShopping_DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineShoppingSystem.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IRepositoryOrder<Order> _order;
        private readonly OrderService _service;
        Logging lg = new Logging();
        public OrderController(IRepositoryOrder<Order> res, OrderService service)
        {
            _order = res;
            _service = service;
        }



        [HttpGet("/PlaceOrders")]
        public string Placeorders(int User_id)
        {
            try
            {
                lg.LogInfo("Entered in Placeorders");
                string a = _service.PlaceOrder(User_id);
                return a;
            }

            
             catch (Exception ex)
            {
                lg.LogError("Message:" + ex.Message + " StackTrace:" + ex.StackTrace);
                throw;
            }
        }
        

        [HttpGet("/Vieworder")]
        public object ViewOrder(int Order_id)
        {
            try
            {
                lg.LogInfo("Entered in ViewOrder");
                return _service.ViewOrders(Order_id);
            }
            catch (Exception ex)
            {
                lg.LogError("Message:" + ex.Message + " StackTrace:" + ex.StackTrace);
                throw;
            }


        }

        [HttpDelete("/CancelOrder")]
        public string CancelOrder(int Order_id)
        {
            try
            {
                lg.LogInfo("Entered in CancelOrder");
                return _service.CancelOrder(Order_id);
            }

            catch (Exception ex)
            {
                lg.LogError("Message:" + ex.Message + " StackTrace:" + ex.StackTrace);
                throw;
            }

        }
    


    }
}
