﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnlineShopping_BAL.Service;
using OnlineShopping_DAL.Interface;
using OnlineShopping_DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Logging_Exceptions;

namespace OnlineShoppingApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        private readonly CartService _cartService;
        private readonly IRepository<CustomerCart> _repository;
        Logging log = new Logging();

        string connstring = @"Server=tcp:onlineshopping.database.windows.net,1433;Initial Catalog=OnlineShoppingDB;Persist Security Info=False;User ID=Training;Password=Password@123;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
        public CartController(CartService cartService, IRepository<CustomerCart> repository)
        {
            _cartService = cartService;
            _repository = repository;
        }

        [HttpPost("/addtocart")]
        public async Task<String> AddToCart([FromBody] CustomerCart cart)
        {

            try
            {
                log.LogInfo("Entered in AddToCart");
                var productAdded = await _cartService.AddToCart(cart);
                return productAdded;
            }
            catch (Exception ex)
            {
                log.LogError("Message:" + ex.Message + " StackTrace:" + ex.StackTrace);
                throw;
            }



        }


        [HttpGet("/viewcart/{userid}")]
        public Object ViewCart([FromRoute] int userid)
        {
            try
            {
                log.LogInfo("Entered in ViewCart");
                var cr = _cartService.ViewCart(userid);
                return cr;
            }
            catch (Exception ex)
            {
                log.LogError("Message:" + ex.Message + " StackTrace:" + ex.StackTrace);
                throw;
            }

        }

        [HttpDelete("/removefromcart/{cartid}/{quantity}")]
        public string RemoveFromCart([FromRoute] int cartid, [FromRoute] int quantity)
        {
            try
            {
                log.LogInfo("Entered in RemoveFromCart");
                return _cartService.RemoveFromCart(cartid, quantity);
            }
            catch (Exception ex)
            {
                log.LogError("Message:" + ex.Message + " StackTrace:" + ex.StackTrace);
                throw;
            }
        }

    }
}
