using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using OnlineShopping_BAL.Helper;
using OnlineShopping_BAL.Interface;
using OnlineShopping_BAL.Service;
using OnlineShopping_DAL.Interface;
using OnlineShopping_DAL.Models;
using OnlineShopping_DAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineShoppingSystem
{
    public class Startup
    {
        private IConfiguration Configuration;
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            string cont = Configuration.GetConnectionString("ConnString");
            services.AddDbContext<OnlineShoppingDBContext>(opts => opts.UseSqlServer(cont));
            services.AddTransient<CartService>();
            services.AddTransient<IRepository<CustomerCart>, RepositoryCart>();

            services.AddTransient<IProductRepository<Product>, RepositoryProduct>();
            services.AddTransient<ICategoryRepository<Category>, RepositoryProduct>();
            services.AddTransient<ProductService, ProductService>();
            services.AddTransient<IRepositoryOrder<Order>, Repositryorder>();
            services.AddTransient<OrderService, OrderService>();

            services.AddAuthentication("BasicAuthentication")
              .AddScheme<AuthenticationSchemeOptions, BasicAuthenticationHandler>("BasicAuthentication", null);
            services.AddScoped<ICustomerService<OnlineShopping_DAL.Models.Customer>, CustomerService>();
            services.AddTransient<ICustomer, RepositoryCustomer>();

            services.AddControllers();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "OnlineShoppingSystem", Version = "v1" });
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "OnlineShoppingSystem v1"));
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthentication();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
