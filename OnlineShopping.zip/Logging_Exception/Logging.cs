﻿using log4net;
using log4net.Config;
using System;
using System.IO;
using System.Reflection;

namespace Logging_Exceptions
{
    public class Logging
    {
        private static readonly ILog logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
      
        string filePath = "log4net.config";
        public void LogError(string ex)
        {
            var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());
           
            XmlConfigurator.Configure(logRepository, new FileInfo(filePath));



            logger.Error("----------------------------------------");
            logger.Error("Date: " + DateTime.Now.ToString());




            if (!string.IsNullOrEmpty(ex))
            {
                logger.Error("Error Message :" + ex);
                //logger.Error("StackTrace :" + ex.StackTrace);



            }
        }


        public void LogInfo(string info)
        {

            var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());

            XmlConfigurator.Configure(logRepository, new FileInfo(filePath));

            logger.Info("----------------------------------------");
            logger.Info("Date: " + DateTime.Now.ToString());

            logger.Info(info);







        }
    }
}

