﻿using OnlineShopping_DAL.Interface;
using OnlineShopping_DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShopping_BAL.Service
{
    public class ProductService
    {
        private readonly IProductRepository<Product> _product;
        private readonly ICategoryRepository<Category> _category;
        public ProductService(IProductRepository<Product> product, ICategoryRepository<Category> category)
        {
            _product = product;
            _category = category;
        }


        public IEnumerable<Product> ViewProducts()
        {
            try
            {
                return _product.GetAllProducts();
            }
            catch
            {
                throw;
            }

        }

        public IEnumerable<Category> ViewCategories()
        {
            try
            {
                return _category.GetAllCategories();
            }
            catch
            {
                throw;
            }

        }

        public Object SearchByProductID(int PId)
        {
            try
            {
                var search = _product.GetProductById(PId);
                return search;
            }
            catch
            {
                throw;
            }

        }

        public Object GetProductByCategoryId(int catId)
        {
            try
            {
                var category = _product.GetProductByCategory(catId);
                return category;
            }
            catch
            {
                throw;
            }

        }

        public Object SearchByPriceRange(int catId, int start, int end)
        {
            try
            {
                var pricerange = _product.GetProductByRange(catId, start, end);
                return pricerange;
            }
            catch
            {
                throw;
            }

        }





    }
}