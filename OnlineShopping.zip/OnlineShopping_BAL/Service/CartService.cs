﻿using OnlineShopping_DAL.Interface;
using OnlineShopping_DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShopping_BAL.Service
{
    public class CartService
    {
        private readonly IRepository<CustomerCart> _cart;
        public CartService(IRepository<CustomerCart> cart)
        {
            _cart = cart;
        }

        public Task<String> AddToCart(CustomerCart cart)
        {
            return _cart.AddToCart(cart);
        }

        public IEnumerable<ProductList> ViewCart(int userid)
        {
            return _cart.ViewCart(userid);
        }

        public String RemoveFromCart(int cartid, int quantity)
        {
            return _cart.RemoveFromCart(cartid, quantity);
        }
    }
}
