using Newtonsoft.Json;
using OnlineShopping_DAL.Interface;
using OnlineShopping_DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShopping_BAL.Service
{
    public class OrderService
    {
        private readonly IRepositoryOrder<Order> _order;

        public OrderService(IRepositoryOrder<Order> order)
        {
            _order = order;
        }

        public string PlaceOrder(int customerId)
        {
            List<CustomerCart> cart = _order.ViewCart(customerId);
            if (cart.Count != 0)
            {
                double TotalPrice = 0;
                Order newOrder;

                foreach (var item in cart)
                {
                    Product p = _order.GetProductById(item.ProductId);
                    TotalPrice += p.Price;
                }
                newOrder = new Order() { CustomerId = customerId, DateofCreated = DateTime.Now, TotalCost = (int)TotalPrice };
                int order_id = _order.PlaceOrder(newOrder, cart);
                return $"Order has been Placed and Order id is : {order_id}";

            }
            else
            {
                return $"Cart is not Found for User Id {customerId}";
            }
        }

        public object ViewOrders(int orderid)
        {

            var result = _order.ViewOrder(orderid);
            if (result != null)
            {
                return JsonConvert.SerializeObject(result);
            }
            else
            {
                return $"Order with ID : {orderid} not found";
            }

        }

        public string CancelOrder(int OrderId)
        {
            var result = _order.CancelOrder(OrderId);
            if (result == true)
            {
                return "Order successfully cancelled.";
            }
            else
            {
                return "Error occurred";
            }



        }
    }


}