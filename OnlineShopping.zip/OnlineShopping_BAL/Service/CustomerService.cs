﻿using OnlineShopping_BAL.Interface;
using OnlineShopping_DAL.Interface;
using OnlineShopping_DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace OnlineShopping_BAL.Service
{
    public class CustomerService : ICustomerService<Customer>
    {
        private readonly ICustomer _customer;

        public CustomerService(ICustomer customer)
        {
            _customer = customer;
        }

        public Customer Authenticate(string username, string password)
        {
            try
            {
                Customer customer = _customer.GetCustomerByName(username);
                if (customer == null) { return null; }

                else if (customer.Customername == username && customer.CustomerPassword == password)
                    return customer;
                else
                    return null;
            }
            catch
            {

                return null;
            }
        }
    }
}
