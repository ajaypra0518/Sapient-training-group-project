﻿using OnlineShopping_DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShopping_BAL.Interface
{
    public interface ICustomerService<T>
    {
        public T Authenticate(string username, string password);
    }
}

