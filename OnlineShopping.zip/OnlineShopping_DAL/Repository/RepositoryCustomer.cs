﻿using OnlineShopping_DAL.Interface;
using OnlineShopping_DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace OnlineShopping_DAL.Repository
{
    public class RepositoryCustomer : ICustomer
    {
        private OnlineShoppingDBContext _context;

        public RepositoryCustomer(OnlineShoppingDBContext context)
        {
            _context = context;
        }
        public Customer GetCustomerByName(string customername)
        {
            try
            {
                var customer = _context.Customers.Where(x => x.Customername == customername).FirstOrDefault();
                return customer;
            }
            catch
            {
                return null;
            }
            //comment
        }
    }
}