﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using OnlineShopping_DAL.Interface;
using OnlineShopping_DAL.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShopping_DAL.Repository
{
    public class RepositoryCart : IRepository<CustomerCart>
    {
        private OnlineShoppingDBContext _context;
        private string connString = "Server=tcp:onlineshopping.database.windows.net,1433;Initial Catalog=OnlineShoppingDB;Persist Security Info=False;User ID=Training;Password=Password@123;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";

        public RepositoryCart(OnlineShoppingDBContext context)
        {
            _context = context;
        }
        public async Task<String> AddToCart(CustomerCart cart)
        {
            try
            {
                  var pid = cart.ProductId;
            Product product = _context.Products.Where(x => x.ProductId == pid).FirstOrDefault();
            CustomerCart customerCart = _context.CustomerCarts.Where(x => x.ProductId == pid && x.CustomerId == cart.CustomerId).FirstOrDefault();
            if(customerCart != null)
            {
                customerCart.Quantity += cart.Quantity;
                _context.SaveChanges();
                return "Product added";
            }

            var stock = product.Stock;
            var diff = stock - cart.Quantity;
            if (diff < 0)
            {
                return "Product cannot be added";
            }

            var productToBeAdded = await _context.CustomerCarts.AddAsync(cart);
            _context.SaveChanges();
            return "Product added";
            } catch (Exception e)
            {
                return e.Message;
            }
          

      }

        public IEnumerable<ProductList> ViewCart(int userid)
        {


            List<ProductList> productLists = new List<ProductList>();
            try
            {

                //sql connection object
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    string spName = @"dbo.[GetCart]";
                    SqlCommand cmd = new SqlCommand(spName, conn);
                    SqlParameter param1 = new SqlParameter();
                    param1.ParameterName = "@userid";
                    param1.SqlDbType = SqlDbType.Int;
                    param1.Value = userid;

                    cmd.Parameters.Add(param1);
                    conn.Open();

                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataReader dr = cmd.ExecuteReader();

                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            ProductList product1 = new ProductList();

                            product1.ProductName = dr.GetString(0);
                            product1.price = dr.GetInt32(1);
                            product1.TotalPrice = dr.GetInt32(2);
                            product1.Quantity = dr.GetInt32(3);

                            productLists.Add(product1);
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                //display error message
                Console.WriteLine("Exception: " + ex.Message);
            }

            return productLists;


        }

        public string RemoveFromCart(int cartid, int quantity)
        {
            try
            {

                //sql connection object
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    string spName = @"dbo.[uspRemoveFromCart]";
                    SqlCommand cmd = new SqlCommand(spName, conn);
                    SqlParameter param1 = new SqlParameter();
                    SqlParameter param2 = new SqlParameter();
                    param1.ParameterName = "@cartid";
                    param2.ParameterName = "@quantity";
                    param1.SqlDbType = SqlDbType.Int;
                    param1.Value = cartid;
                    param2.Value = quantity;

                    cmd.Parameters.Add(param1);
                    cmd.Parameters.Add(param2);
                    conn.Open();

                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataReader dr = cmd.ExecuteReader();

                    
                }

            }
            catch (Exception ex)
            {
                //display error message
                return ex.Message;
            }

            return "Item removed from Cart successfully";
        }

      
    }
}
