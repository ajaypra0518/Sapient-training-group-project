﻿using OnlineShopping_DAL.Interface;
using OnlineShopping_DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShopping_DAL.Repository
{
    public class RepositoryProduct : IProductRepository<Product>, ICategoryRepository<Category>
    {
        private OnlineShoppingDBContext dbContext;
        public RepositoryProduct(OnlineShoppingDBContext context)
        {
            dbContext = context;
        }

        public IEnumerable<Category> GetAllCategories()
        {
            try
            {
                return dbContext.Categories;
            }
            catch
            {
                throw;
            }

        }
        public IEnumerable<Product> GetAllProducts()
        {
            try
            {
                return dbContext.Products;
            }
            catch
            {
                throw;
            }

        }
        public Object GetProductById(int PId)
        {
            try
            {
                var search = dbContext.Products.Where(x => x.ProductId.Equals(PId)).ToList();
                if (search.Count<Product>() <= 0)
                {
                    return "Product doesnot exist in the list: available ProductId between 1-24!!!";
                }

                return search;
            }
            catch
            {
                throw;
            }

        }

        public Object GetProductByRange(int CategoryId, int startRange, int endRange)
        {
            try
            {
                var category = dbContext.Products.Where(x => x.CategoryId.Equals(CategoryId) && x.Price >= startRange && x.Price <= endRange);
                if (category.Count<Product>() <= 0)
                {
                    return "No record found.";
                }

                return category;
            }
            catch
            {
                throw;
            }

        }

        

        public Object GetProductByCategory(int CategoryID)
        {
            try
            {
                var data = dbContext.Products.Where(x => x.CategoryId.Equals(CategoryID));
                if (data.Count<Product>() <= 0)
                {
                    return "CategoryId doesnot exist!! available id from 101 to 107";
                }

                return data;
            }
            catch
            {
                throw;
            }
        }

        public void UpdateProduct(Product obj)
        {
            try
            {
                dbContext.Update(obj);
                dbContext.SaveChanges();
            }
            catch
            {
                throw;
            }
        }
    }
}
