﻿using Microsoft.EntityFrameworkCore;
using OnlineShopping_DAL.Interface;
using OnlineShopping_DAL.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShopping_DAL.Repository
{
    public class Repositryorder : IRepositoryOrder<Order>
    {
        private readonly OnlineShoppingDBContext _context;

        public Repositryorder(OnlineShoppingDBContext con)
        {
            _context = con;
        }


        public int PlaceOrder(Order order, List<CustomerCart> cart)
        {
            using (var transaction = _context.Database.BeginTransaction())
            {
                try
                {
                    //order
                    _context.Orders.Add(order);
                    _context.SaveChanges();

                    int order_id = _context.Orders.Where(x => x.CustomerId == order.CustomerId).OrderBy(s => s.OrderId).Last().OrderId;

                    //Order status
                    OrderStatus orderstatus = new OrderStatus();
                    orderstatus.OrderId = order_id;
                    orderstatus.Status = "Successful";
                    orderstatus.PaymentType = "Cash on delivery";
                    orderstatus.UserDeliverydate = DateTime.Today.AddDays(2);
                    _context.OrderStatuses.Add(orderstatus);
                    _context.SaveChanges();

                    //Add product to Order Product
                    foreach (var item in cart)
                    {
                        Product p = _context.Products.Where(x => x.ProductId == item.ProductId).FirstOrDefault();
                        if (item.Quantity <= p.Stock)
                        {
                            OrderProduct or_product = new OrderProduct() { OrderId = order_id, ProductId = item.ProductId, Quantity = item.Quantity, TotalCost = 0 };
                            _context.OrderProducts.Add(or_product);

                            p.Stock -= item.Quantity;
                            _context.Products.Update(p);

                            _context.CustomerCarts.Remove(item);

                            _context.SaveChanges();
                        }
                        else
                        {
                            throw new Exception();
                        }



                    }
                    _context.SaveChanges();

                    //commit the changes
                    transaction.Commit();
                    return order_id;
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    throw new Exception("Error Occured");
                }
            }
        }



        public IEnumerable ViewOrder(int id) //Order id
        {
            var test = _context.OrderProducts.Where(x => x.OrderId == id).ToList();
            if (test.Count != 0)
            {
                try
                {
                    //product related information
                    Hashtable result = new Hashtable();
                    var pr = _context.OrderProducts.Where(x => x.OrderId == id);

                    var data = pr.Join(_context.Products,
                                                      orderproduct => orderproduct.ProductId,
                                                      products => products.ProductId,
                                                      (orderproduct, products) => new
                                                      {
                                                          Products_Name = products.ProductName,
                                                          price = products.Price,
                                                          quty = orderproduct.Quantity,
                                                          Description = products.Description
                                                      }
                                                  ).ToList();


                    // order related information
                    var order = _context.Orders.Where(x => x.OrderId == id);
                    var data1 = order.Join(_context.OrderStatuses,
                                                      orders => orders.OrderId,
                                                      orderstatus => orderstatus.OrderId,
                                                      (orders, orderstatus) => new
                                                      {
                                                          OrderId = orders.OrderId,
                                                          DateOfCreated = orders.DateofCreated,
                                                          UserDeliverydate = orderstatus.UserDeliverydate,
                                                          Status = orderstatus.Status,
                                                          Price = orders.TotalCost
                                                      }
                                                  ).ToList();

                    result.Add("Order_Information", data1);
                    result.Add("Product_information", data);

                    return result;
                }
                catch (Exception e)
                {
                    throw;
                }
            }
            else
            {

                return null;
            }

        }

        public bool CancelOrder(int id)
        {
            using (var transaction = _context.Database.BeginTransaction())
            {
                try
                {

                    _context.OrderStatuses.Remove(_context.OrderStatuses.Where(x => x.OrderId == id).FirstOrDefault());


                    var or_pro = _context.OrderProducts.Where(x => x.OrderId == id).ToList();
                    foreach (var item in or_pro)
                    {
                        Product p = _context.Products.Where(x => x.ProductId == item.ProductId).FirstOrDefault();
                        p.Stock += item.Quantity;
                        _context.Products.Update(p);
                        _context.OrderProducts.Remove(item);

                        _context.SaveChanges();
                    }
                    _context.Orders.Remove(_context.Orders.Where(x => x.OrderId == id).FirstOrDefault());
                    _context.SaveChanges();
                    transaction.Commit();
                    return true;
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    throw new Exception("Error Occured");
                }

            }


        }


        /// removeble
        public Product GetProductById(int PId)
        {

            return _context.Products.Where(x => x.ProductId.Equals(PId)).First();


        }

        public void UpdateProduct(Product obj)
        {
            try
            {
                _context.Update(obj);
                _context.SaveChanges();
            }
            catch
            {
                throw;
            }
        }

        public List<CustomerCart> ViewCart(int userid)
        {
            var carts = _context.CustomerCarts.Where(x => x.CustomerId == userid);
            List<CustomerCart> cart = new List<CustomerCart>();
            foreach (var item in carts)
            {
                cart.Add(item);
            }
            return cart;

        }


    }
}
