﻿
using OnlineShopping_DAL.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShopping_DAL.Interface
{
    public interface IRepositoryOrder<T>
    {
       // Removeble
       public List<CustomerCart> ViewCart(int userid);
       public void UpdateProduct(Product obj);
        public Product GetProductById(int PId);
        //
       public int PlaceOrder(T obj, List<CustomerCart> orderproduct);
     
        public IEnumerable ViewOrder(int id);
        public bool CancelOrder(int id);
        
    }
}
