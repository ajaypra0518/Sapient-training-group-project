﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShopping_DAL.Interface
{
    public interface IProductRepository<T>
    {

        public Object GetProductById(int ProductID);

        public IEnumerable<T> GetAllProducts();
        public Object GetProductByRange(int CategoryId, int startRange, int endRange);

        public Object GetProductByCategory(int CategoryID);

        public void UpdateProduct(T obj);

    }
}
