﻿using OnlineShopping_DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShopping_DAL.Interface
{
    public interface IRepository<CustomerCart>
    {
        public Task<String> AddToCart(CustomerCart cart);

        public IEnumerable<ProductList> ViewCart(int userid);

        public String RemoveFromCart(int cartid, int quantity);
    }
}
