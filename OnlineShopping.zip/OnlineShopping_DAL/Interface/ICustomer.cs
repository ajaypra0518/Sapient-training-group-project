﻿using OnlineShopping_DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShopping_DAL.Interface
{
    public interface ICustomer

    {
        public Customer GetCustomerByName(string customername);
    }
}
