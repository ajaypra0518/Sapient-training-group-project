﻿--Trigger
CREATE TRIGGER UpdateStockInsert 
ON CustomerCart
AFTER INSERT
AS
	BEGIN TRY
		DECLARE @Quant INT
		DECLARE @Producid INT
		SET @Quant = (SELECT TOP 1 Quantity FROM CustomerCart WITH(NOLOCK) ORDER BY CartId DESC)
		SET @ProducId = (SELECT TOP 1 ProductId FROM CustomerCart WITH(NOLOCK) ORDER BY CartId DESC)	
		UPDATE Products SET Stock = Stock - @Quant WHERE ProductID = @producid
	END TRY
	BEGIN CATCH
		DELETE FROM CustomerCart WHERE CartId = (SELECT TOP 1 CartId FROM CustomerCart WITH(NOLOCK) ORDER BY CartId DESC)
	END CATCH
go

--StoredProceedure
alter procedure GetCart(
	@userid int
)
as 
begin 
	create table #temp(product varchar(100), price int, totalprice int, quantity int)
	
	insert into #temp
	select p.ProductName as product
	, p.price as price
	, (p.price * c.quantity) as totalprice
	, c.quantity as quantity
	from products p with(nolock) inner join CustomerCart c with(nolock) on c.ProductID = p.ProductID
	where c.CustomerID = @userid

	select * from #temp
end 

--Stored Procedure

GO
CREATE PROCEDURE uspRemoveFromCart(
	@cartid INT
	,@quantity INT
)
AS
BEGIN
	if(@quantity > (select quantity from CustomerCart where CartID = @cartid))
		BEGIN
			Return
		END
	else if(@quantity < (select quantity from CustomerCart where CartID = @cartid))
		BEGIN
			update CustomerCart set Quantity = Quantity - @quantity
			where CartID = @cartid
		END
	else if(@quantity = (select quantity from CustomerCart where CartID = @cartid))
		BEGIN
			delete from CustomerCart where CartID = @cartid
		END
	update Products set Stock = stock + @quantity
	where ProductID = ( select ProductID from CustomerCart where CartID = @cartid)
END
GO