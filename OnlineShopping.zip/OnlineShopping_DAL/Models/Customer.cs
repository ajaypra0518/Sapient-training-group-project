﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OnlineShopping_DAL.Models
{
    public partial class Customer
    {
        public Customer()
        {
            CustomerCarts = new HashSet<CustomerCart>();
            Orders = new HashSet<Order>();
        }

        public int CustomerId { get; set; }
        public string Customername { get; set; }
        public string CustomerPassword { get; set; }
        public string CustomerAddress { get; set; }
        public string PhoneNumber { get; set; }
        public bool? IsAuthenticated { get; set; }

        public virtual ICollection<CustomerCart> CustomerCarts { get; set; }
        public virtual ICollection<Order> Orders { get; set; }
    }
}
