﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

#nullable disable

namespace OnlineShopping_DAL.Models
{
    [Table("CustomerCart")]
    public partial class CustomerCart
    {
        [Key]
        [Column("CartID")]
        public int CartId { get; set; }
        [Column("ProductID")]
        public int ProductId { get; set; }
        [Column("CustomerID")]
        public int CustomerId { get; set; }
        public int Quantity { get; set; }

        [ForeignKey(nameof(CustomerId))]
        [InverseProperty("CustomerCarts")]
        [System.Text.Json.Serialization.JsonIgnore]
        public virtual Customer Customer { get; set; }
        [ForeignKey(nameof(ProductId))]
        [InverseProperty("CustomerCarts")]
        [System.Text.Json.Serialization.JsonIgnore]
        public virtual Product Product { get; set; }
    }
}
