﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OnlineShopping_DAL.Models
{
    public partial class Order
    {
        public Order()
        {
            OrderProducts = new HashSet<OrderProduct>();
            OrderStatuses = new HashSet<OrderStatus>();
        }

        public int OrderId { get; set; }
        public int? CustomerId { get; set; }
        public DateTime DateofCreated { get; set; }
        public int? TotalCost { get; set; }

        [System.Text.Json.Serialization.JsonIgnore]
        public virtual Customer Customer { get; set; }
        [System.Text.Json.Serialization.JsonIgnore]
        public virtual ICollection<OrderProduct> OrderProducts { get; set; }
        [System.Text.Json.Serialization.JsonIgnore]
        public virtual ICollection<OrderStatus> OrderStatuses { get; set; }
    }
}
