﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OnlineShopping_DAL.Models
{
    public partial class OrderStatus
    {
        public int OrderStatusId { get; set; }
        public int? OrderId { get; set; }
        public DateTime UserDeliverydate { get; set; }
        public string Status { get; set; }
        public string PaymentType { get; set; }

        [System.Text.Json.Serialization.JsonIgnore]
        public virtual Order Order { get; set; }
    }
}
