﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OnlineShopping_DAL.Models
{
    public partial class Product
    {
        public Product()
        {
            CustomerCarts = new HashSet<CustomerCart>();
            OrderProducts = new HashSet<OrderProduct>();
        }

        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string Description { get; set; }
        public double Price { get; set; }
        public int? Stock { get; set; }
        public DateTime DateOfManufacture { get; set; }
        public int? CategoryId { get; set; }

        
        [System.Text.Json.Serialization.JsonIgnore]
        public virtual Category Category { get; set; }
        [System.Text.Json.Serialization.JsonIgnore]
        public virtual ICollection<CustomerCart> CustomerCarts { get; set; }
        [System.Text.Json.Serialization.JsonIgnore]
        public virtual ICollection<OrderProduct> OrderProducts { get; set; }
    }
}
