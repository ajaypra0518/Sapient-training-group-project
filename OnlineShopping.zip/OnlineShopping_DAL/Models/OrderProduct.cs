﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OnlineShopping_DAL.Models
{
    public partial class OrderProduct
    {
        public int OpNo { get; set; }
        public int? OrderId { get; set; }
        public int? ProductId { get; set; }
        public int? Quantity { get; set; }
        public int? TotalCost { get; set; }

        [System.Text.Json.Serialization.JsonIgnore]
        public virtual Order Order { get; set; }
        [System.Text.Json.Serialization.JsonIgnore]
        public virtual Product Product { get; set; }
    }
}
